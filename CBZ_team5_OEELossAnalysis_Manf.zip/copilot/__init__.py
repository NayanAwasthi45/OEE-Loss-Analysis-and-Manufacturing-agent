# Copilot module initialization
